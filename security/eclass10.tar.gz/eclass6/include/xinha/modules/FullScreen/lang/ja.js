// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
  "Maximize/Minimize Editor": "エディタの最大化/最小化"
};