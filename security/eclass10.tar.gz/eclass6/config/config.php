<?php
/* ========================================================
 * OpeneClass 2.2 configuration file
 * Automatically created by install on 2019-04-19 13:09
 * ======================================================== */

$urlServer = "http://password132.csec.chatzi.org/";
$urlAppend = "";
$webDir    = "/var/www/html/" ;

$mysqlServer = "localhost";
$mysqlUser = "root";
$mysqlPassword = "Sc9VCn4Wwp";
$mysqlMainDb = "eclass";
$phpMyAdminURL = "../admin/mysql/";
$phpSysInfoURL = "../admin/sysinfo/";
$emailAdministrator = "webmaster@localhost";
$administratorName = "Διαχειριστής";
$administratorSurname = "Πλατφόρμας";
$siteName = "Open eClass";

$telephone = "+30 2xx xxxx xxx";
$fax = "";
$emailhelpdesk = "";

$language = "greek";

$Institution = "Ακαδημαϊκό Διαδίκτυο GUNet ";
$InstitutionUrl = "http://www.gunet.gr/";
$postaddress = "";

$have_latex = FALSE;
$close_user_registration = FALSE;

$persoIsActive = TRUE;
$durationAccount = "126144000";

define("UTF8", true);


$encryptedPasswd = true;
